#include <stdio.h>

int main()
{
	printf("Learning autotool \n");
	return 0;

}
