#include <stdio.h>
int main()
{
	printf("Hello CMake\n");
	return 0;
}
