#include <stdio.h>
#include "mylib.h"

int main()
{
	print("Learning Dynamic Library Usage\n", 5);
	return 0;
}
