#include <stdio.h>
#include "mylib.h"

int main()
{
	print("Learning static Library usage\n", 5);
	return 0;

}
