#include "mylib.h"

int add(int quant1, int quant2)
{
	return(quant1 + quant2);
}

int div(int quant1, int quant2)
{
	return(quant1 / quant2);
}

int mul(int quant1, int quant2)
{
	return(quant1 * quant2);
}

int sub(int quant1, int quant2)
{
	return(quant1 - quant2);
}
